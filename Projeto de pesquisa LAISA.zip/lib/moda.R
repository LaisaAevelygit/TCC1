### MODA

par(mfrow=c(1,3))
x <- c(rvonmises(200, circular(pi/2), 0), rvonmises(200, circular(pi), 0))
plot.circular(x, main = "Uniforme") ### UNIFORME

y = c(rvonmises(200, circular(pi/2), 10), rvonmises(200, circular(pi), 10))
plot.circular(y, main = "Multimodal")  ### MULTIMODAL

z = c(rvonmises(200, circular(pi/2), 50), rvonmises(200, circular(pi/4), 50))
plot.circular(z, main = "Unimodal" ) ### UNIMODAL


